# fasta_tools
a few tools for dealing with fasta files


